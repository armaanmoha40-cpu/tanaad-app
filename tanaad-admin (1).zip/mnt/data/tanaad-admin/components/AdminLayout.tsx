import Link from 'next/link';

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">TANAAD APP Admin</div>
        <nav className="nav">
          <Link href="/dashboard">Dashboard</Link>
          <Link href="/deposits">Dhigasho</Link>
          <Link href="/withdrawals">La Bixid</Link>
          <Link href="/users">Users</Link>
          <Link href="/notifications">Notifications</Link>
        </nav>
      </aside>
      <main className="main">{children}</main>
    </div>
  );
}
