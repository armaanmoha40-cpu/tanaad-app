'use client';
import { useState } from 'react';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from '@/lib/firebase';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  async function login(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    try {
      await signInWithEmailAndPassword(auth, email, password);
      router.push('/dashboard');
    } catch {
      setError('Login wuu fashilmay. Hubi email/password.');
    }
  }

  return (
    <div className="login-wrap">
      <form className="login-card" onSubmit={login}>
        <div className="logo">TA</div>
        <h1>TANAAD APP Admin</h1>
        <p>Gal admin panel-ka si aad u maamusho deposits, withdrawals iyo users.</p>
        <label>Email</label>
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="admin@tanaad.com" />
        <label>Password</label>
        <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="********" />
        {error && <p style={{color:'#dc2626'}}>{error}</p>}
        <button className="btn-primary">Gal Admin Panel</button>
      </form>
    </div>
  );
}
