import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'TANAAD APP Admin',
  description: 'Admin panel for TANAAD APP e-wallet exchange',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="so">
      <body>{children}</body>
    </html>
  );
}
